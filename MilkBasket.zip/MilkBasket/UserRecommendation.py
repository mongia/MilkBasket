from flask import Flask
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.metrics import pairwise_distances
from sklearn.metrics.pairwise import cosine_similarity
import json


app = Flask(__name__)

def find_n_neighbours(df,n):
    order = np.argsort(df.values, axis=1)[:, :n]
    df = df.apply(lambda x: pd.Series(x.sort_values(ascending=False)
           .iloc[:n].index,
          index=['top{}'.format(i) for i in range(1, n+1)]), axis=1)
    return df


def User_item_score(user,train_data,sim_user_30_p,product_user,final_prod,Mean,similarity_with_prod,df_custmatrix):
    Prod_bought_by_user = df_custmatrix.columns[df_custmatrix[df_custmatrix.index == user].notna().any()].tolist()
    return json.dumps(Prod_bought_by_user)
    a = sim_user_30_p[sim_user_30_p.index == user].values
    b = a.squeeze().tolist()
    d = product_user[product_user.index.isin(b)]
    l = ','.join(d.values)
    Prod_seen_by_similar_users = l.split(',')
    Prod_under_consideration = list(set(Prod_seen_by_similar_users) - set(list(map(str, Prod_bought_by_user))))
    Prod_under_consideration = list(map(int, Prod_under_consideration))
    score = []
    for item in Prod_under_consideration:
        c = final_prod.loc[:, item]
        d = c[c.index.isin(b)]
        f = d[d.notnull()]
        avg_user = Mean.loc[Mean['userId'] == user, 'rating'].values[0]
        index = f.index.values.squeeze().tolist()
        corr = similarity_with_prod.loc[user, index]
        fin = pd.concat([f, corr], axis=1)
        fin.columns = ['adg_score', 'correlation']
        fin['score'] = fin.apply(lambda x: x['adg_score'] * x['correlation'], axis=1)
        nume = fin['score'].sum()
        deno = fin['correlation'].sum()
        final_score = avg_user + (nume / deno)
        score.append(final_score)
    data = pd.DataFrame({'product_id': Prod_under_consideration, 'score': score})
    top_5_recommendation = data.sort_values(by='score', ascending=False).head(5)
    Prod_Name = top_5_recommendation.merge(train_data, how='inner', on='product_id')
    #Prod_Names = Prod_Name.title.values.tolist()
    return  Prod_Name.tolist();


global train_data
global sim_user_30_p
global product_user
global final_prod
global Mean
global similarity_with_prod


@app.route("/")
def getRecommenededProduct(user_id):
    df_orders = pd.read_csv(os.getcwd()+'/milkbasket_hackathon_sample_data.csv')
    train_data, test_data = train_test_split(df_orders, test_size=0.25)
    train_data.head(5)
    df_custdata = train_data.groupby(['customer_id']).size().sort_values(ascending=False).reset_index(name='count')
    df_custdata = train_data.groupby(['customer_id', 'product_id']).size().sort_values(ascending=False).reset_index(
        name='count')
    df_custmatrix = pd.pivot_table(df_custdata, values='count', index='customer_id', columns='product_id')
    Mean = df_custdata.groupby(by="customer_id", as_index=False)['count'].mean()
    df_custmatrix_norm = (df_custmatrix - df_custmatrix.min()) / (df_custmatrix.max() - df_custmatrix.min())
    final_prod = df_custmatrix_norm.fillna(df_custmatrix_norm.mean(axis=0))
    final_user = df_custmatrix_norm.apply(lambda row: row.fillna(row.mean()), axis=1)
    final_user.fillna(final_user.mean(), inplace=True)
    b = cosine_similarity(final_user)
    np.fill_diagonal(b, 0)
    similarity_with_user = pd.DataFrame(b, index=final_user.index)
    similarity_with_user.columns = final_user.index
    # user similarity on replacing NAN by item(movie) avg
    final_prod.fillna(0, inplace=True)
    #return  final_prod.to_json()
    cosine = cosine_similarity(final_prod)
    np.fill_diagonal(cosine, 0)
    similarity_with_prod = pd.DataFrame(cosine, index=final_prod.index)
    similarity_with_prod.columns = final_user.index
    sim_user_30_c = find_n_neighbours(similarity_with_user, 30)
    sim_user_30_p = find_n_neighbours(similarity_with_prod, 30)
    train_data = train_data.astype({"product_id": str})
    return train_data.to_json()
    product_user = train_data.groupby(by='customer_id')['product_id'].apply(lambda x: ','.join(x))
    predicted_products = User_item_score(user_id,train_data,sim_user_30_p,product_user,final_prod,Mean,similarity_with_prod,df_custmatrix)
    return  predicted_products


if __name__ == '__main__':
    app.run(debug=True)